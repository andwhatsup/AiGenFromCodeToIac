url_shortener
===

## Introduction
A simple URL shortening service.

## Dependencies
- AWS dynamo DB table
- AWS Lambda (python runtime)
- Boto3
